package com.timetable;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniversityTimetableManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
